async function buscar()
{
    let response = await fetch('http://192.168.206.10/cadastro_pacientes/listar');
    let obj = await response.json()
    return obj
}
 
 
function tH(keys) {
    keys.push('Editar')
    let table1 = document.createElement('table');
    let thead = document.createElement('thead');
    let tr = document.createElement('tr');
    thead.append(tr);
    table1.append(thead);
    let tbody = document.createElement('tbody');
    table1.append(tbody);
    $('#main').append(table1);
    
   
    for (let index = 0; index < keys.length; index++) {
        const element = keys[index];
        const tH = document.createElement('th');
        tH.innerText = element;
        tr.append(tH);
    }
   
        $("#main").append(table1);

        $(table1).append(thead) ;
        $(table1).append(tbody) ;
     
        $(table1).addClass('table table-stripped table-dark')
        $(tbody).addClass('tbody');
       
     
}
 
function arrumar(obj){      
    
     

        const values = Object.values(obj)
        const tr = document.createElement('tr'); 
        for (let i = 0; i < values.length; i++) {  
            const el = values[i];
            const td = document.createElement('td'); 
            td.innerText = el
            tr.append(td);
            
            // tr.append(button)
            
        }
    const button = document.createElement('button')
    
    $(button).addClass('btn btn-all btn-primary btn-lg')
    $(button).text('Click')
    button.id = values[0]
    const td2=document.createElement('td')
    td2.append(button)
    tr.append(td2)
    // $('td').val().addClass('invisible')
    $('.tbody').append(tr)
  

        
        // const tr = document.createElement('tr');
        // const nome = document.createElement('td');
        // const data_nascimento = document.createElement('td');
        // const bairro = document.createElement('td');
        // const cep = document.createElement('td');
        // const cpf = document.createElement('td');
        // const email = document.createElement('td');
        // const id = document.createElement('td');
        // const nome_mae = document.createElement('td');
        // const sexo = document.createElement('td');
        // const nome_rua = document.createElement('th');
        // const numero_casa = document.createElement('th');
        // const uf = document.createElement('th');
        // const tdbtn = document.createElement('td');
        // const button = document.createElement('button');
 
        // nome.innerText = el.nome;
        // data_nascimento.innerText = el.data_nascimento;
        // bairro.innerText = el.bairro;
        // cep.innerText = el.cep;
        // cpf.innerText = el.cpf;
        // email.innerText = el.email;
        // id.innerText = el.id;
        // nome_mae.innerText = el.nome_mae;
        // numero_casa.innerText = el.numero_casa;
        // nome_rua.innerText = el.nome_rua
        // sexo.innerText = el.sexo;
        // uf.innerText = el.uf;
        // button.innerHTML = "Click";
        // button.value = el.id
        // button.id = el.id
     
 
        // tr.append(id);
        // tr.append(nome);
        // tr.append(data_nascimento);
        // tr.append(sexo);
        // tr.append(nome_mae);
        // tr.append(email);
        // tr.append(cpf);
        // tr.append(cep);
        // tr.append(nome_rua)
        // tr.append(numero_casa);
        // tr.append(bairro);
        // tr.append(uf);
        // tr.append(button)
        // tdbtn.append(button)
        // tr.append(tdbtn)
 
       
      
   
       
 
        button.addEventListener('click' , () => {
            alert (`o id é ${button.id}`)
        });
       
 
       
    }

 
 
$(document).ready(async ()=>{
    let obj = await buscar();
    tH(Object.keys(obj[0]));
 


    for (let index = 0; index < obj.length; index++) {
        const element = obj[index];
        arrumar(element) 
        console.log('passando elemento: ', element)
        
    }
   
});
